---
name: Documentation improvement
about: Create a report to help us improve the documentation. Alternatively you can just open a pull request with the suggested change.
title: ''
labels: Documentation
assignees: ''

---

#### Describe the issue linked to the documentation

<!--
Tell us about the confusion introduced in the documentation.
-->

#### Suggest a potential alternative/fix

<!--
Tell us how we could improve the documentation in this regard.
-->
